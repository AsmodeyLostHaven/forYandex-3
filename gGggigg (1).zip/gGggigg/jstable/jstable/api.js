const start = () => {
    https: //sheets.googleapis.com/v4/spreadsheets/1wtNdDAXRL0D-7isbVWCgt8oW5wsfmH3B00m620Mg6uY/?key=AIzaSyCrB3NcC8wfeQiLQOq2KvHJ4QIQDuv8E3M&includeGridData=true

        gapi.client.init({
        'apiKey': 'AIzaSyCrB3NcC8wfeQiLQOq2KvHJ4QIQDuv8E3M',
        'discoveryDocs': ["https://sheets.googleapis.com/$discovery/rest?version=v4"],
    }).then(() => {
        return gapi.client.sheets.spreadsheets.values.get({
            spreadsheetId: '1rMX_ScDcE4XwIPfYV64fCn493I_n7Lz1NjaTHcUkqp0',
            range: 'raspisanie!A1:H50', // for example: List 1!A1:B6
        })
    }).then((response) => {
        // Parse the response data
        const loadedData = response.result.values;

        // populate HTML table with data
        const table = document.getElementsByTagName('table')[0];

        // add column headers

        const columnHeaders = document.createElement('tr');
        columnHeaders.innerHTML = `<th>${loadedData[0][0]}</th>
<th>${loadedData[0][1]} <th>${loadedData[0][2]} <th>${loadedData[0][3]} <th>${loadedData[0][4]}`;
        table.appendChild(columnHeaders);



        // add table data rows
        for (let i = 1; i < loadedData.length; i++) {
            const tableRow = document.createElement('tr');
            tableRow.innerHTML = `<td>${loadedData[i][0]}</td>
<td>${loadedData[i][1]}</td> <td>${loadedData[i][2]}</td> <td>${loadedData[i][3]}</td> <td>${loadedData[i][4]}</td> `;
            table.appendChild(tableRow);

        }
    }).catch((err) => {
        console.log(err.error.message);
    });
};

// Load the JavaScript client library
gapi.load('client', start);