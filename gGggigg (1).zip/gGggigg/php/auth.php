<?php
$mail = filter_var(trim($_POST['mail']),FILTER_SANITIZE_STRING);
$passw = filter_var(trim($_POST['passw']),FILTER_SANITIZE_STRING);

$passw = md5($passw);
$mysql = new mysqli('localhost', 'root', '', 'register-bd');

$result=$mysql->query("SELECT * FROM `users` WHERE `mail`='$mail' AND `passw`='$passw'"); 
$user = $result->fetch_assoc();
if(count($user) == 0) {
echo "User not found";
exit();
}
setcookie('user',$user['mail'], time() + 3600*24, "/");
$mysql->close();
header('Location:/');
?>