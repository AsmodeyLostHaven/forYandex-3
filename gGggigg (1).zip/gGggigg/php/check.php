<?php
$FIO = filter_var(trim($_POST['FIO']),FILTER_SANITIZE_STRING);
$mail = filter_var(trim($_POST['mail']),FILTER_SANITIZE_STRING);
$group = filter_var(trim($_POST['group']),FILTER_SANITIZE_STRING);
$passw = filter_var(trim($_POST['passw']),FILTER_SANITIZE_STRING);


if(mb_strlen($FIO) < 3 || mb_strlen($FIO) > 300) {
    echo "Недопустимая длинна ФИО";
    exit();
} else if(mb_strlen($mail) < 3 ||  mb_strlen($mail) > 300) {
    echo "Недопустимая длинна почты";
    exit();
} else if(mb_strlen($group) < 3  ||  mb_strlen($group) > 300) {
    echo "Недопустимая длинна группы";
    exit();
} else if(mb_strlen($passw) < 8 ||  mb_strlen($passw) > 300){
    echo "Недопустимая длинна пароля";
    exit();
}

$passw = md5($passw);
$mysql = new mysqli('localhost', 'root', '', 'register-bd');
$mysql->query("INSERT INTO `users` (`FIO`, `mail`, `group`, `passw`)
VALUES('$FIO', '$mail', '$group', '$passw')");

$mysql->close();
header('Location:/');
exit();
?>
