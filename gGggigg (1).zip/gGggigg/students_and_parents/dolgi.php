<?php
$id='1EkuZl7i37MGt65PAYKzNkvOkZEgCb_LDtT7ZxKfOmoc';
$gid= 0;
$range = 'A1:P20';
$csv = file_get_contents('https://docs.google.com/spreadsheets/d/' . $id . '/export?format=csv&gid=' . $gid. '&range=' . $range);
$csv = explode("\r\n", $csv);
$array = array_map('str_getcsv', $csv);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <script src="https://sheets.googleapis.com/v4/spreadsheets/1wtNdDAXRL0D-7isbVWCgt8oW5wsfmH3B00m620Mg6uY/?key=AIzaSyCrB3NcC8wfeQiLQOq2KvHJ4QIQDuv8E3M&includeGridData=true"></script>
    <title>main</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="table" href="/jstable/jstable/api.js">
    <link rel="js" href="./script.js">

</head>

<body>
    <!-- partial:index.partial.html -->
    <div class="video-bg">
        <video width="320" height="240" autoplay loop muted>
  <source src="https://assets.codepen.io/3364143/7btrrd.mp4" type="video/mp4">
Your browser does not support the video tag.
</video>
    </div>
    <div class="dark-light">
        <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round">
     <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" /></svg>
    </div>
    <div class="app">
        <div class="header">
            <img src="MikLogo.svg">
            <div class="header-menu">
                <a class="menu-link" href="index.php"> Расписание</a>
                <a class="menu-link" href="marks.php">Мои оценки</a>
                <a class="menu-link" href="dolgi.php">Задолженности</a>
                <a class="menu-link" href="menu.php">Меню столовой</a>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Найти">
            </div>
            <div class="header-profile">
                <div class="notification">
                    <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
     <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
    </svg>
                </div>
                </svg>

            </div>
        </div>
        <div class="wrapper">
            <div class="left-side">
                <div class="side-wrapper">
                    <div class="side-title">Предметы</div>
                    <div class="side-menu">
                        <a href="#">
                            <g xmlns="http://www.w3.org/2000/svg" fill="currentColor">
                                <path d="M0 0h128v128H0zm0 0M192 0h128v128H192zm0 0M384 0h128v128H384zm0 0M0 192h128v128H0zm0 0" data-original="#bfc9d1" />
                            </g>
                            <path xmlns="http://www.w3.org/2000/svg" d="M192 192h128v128H192zm0 0" fill="currentColor" data-original="#82b1ff" />
                            <path xmlns="http://www.w3.org/2000/svg" d="M384 192h128v128H384zm0 0M0 384h128v128H0zm0 0M192 384h128v128H192zm0 0M384 384h128v128H384zm0 0" fill="currentColor" data-original="#bfc9d1" />
                            </svg>
                            Мдк 03.01
                        </a>
                        <a href="#">
                            <path d="M243.158 61.361v-57.6c0-3.2 4-4.9 6.7-2.9l118.4 87c2 1.5 2 4.4 0 5.9l-118.4 87c-2.7 2-6.7.2-6.7-2.9v-57.5c-87.8 1.4-158.1 76-152.1 165.4 5.1 76.8 67.7 139.1 144.5 144 81.4 5.2 150.6-53 163-129.9 2.3-14.3 14.7-24.7 29.2-24.7 17.9 0 31.8 15.9 29 33.5-17.4 109.7-118.5 192-235.7 178.9-98-11-176.7-89.4-187.8-187.4-14.7-128.2 84.9-237.4 209.9-238.8z"
                            />
                            </svg>
                            Физ-ра
                        </a>
                    </div>
                </div>
                <div class="side-wrapper">
                    <div class="side-title">Практика</div>
                    <div class="side-menu">
                        <a href="practicaprozv.php">
                            <path d="M287.396 216.317c23.845 23.845 23.845 62.505 0 86.35s-62.505 23.845-86.35 0-23.845-62.505 0-86.35 62.505-23.845 86.35 0" />
                            <path d="M427.397 91.581H385.21l-30.544-61.059H133.76l-30.515 61.089-42.127.075C27.533 91.746.193 119.115.164 152.715L0 396.86c0 33.675 27.384 61.074 61.059 61.074h366.338c33.675 0 61.059-27.384 61.059-61.059V152.639c-.001-33.674-27.385-61.058-61.059-61.058zM244.22 381.61c-67.335 0-122.118-54.783-122.118-122.118s54.783-122.118 122.118-122.118 122.118 54.783 122.118 122.118S311.555 381.61 244.22 381.61z"
                            />
                            </svg>
                            Производственная
                        </a>
                        <a href="practicauch.php">
                            <circle cx="295.099" cy="327.254" r="110.96" transform="rotate(-45 295.062 327.332)" />
                            <path d="M471.854 338.281V163.146H296.72v41.169a123.1 123.1 0 01121.339 122.939c0 3.717-.176 7.393-.5 11.027zM172.14 327.254a123.16 123.16 0 01100.59-120.915L195.082 73.786 40.146 338.281H172.64c-.325-3.634-.5-7.31-.5-11.027z" />
                            </svg>
                            Учебная
                        </a>
                    </div>
                </div>
                <div class="side-wrapper">
                    <div class="side-title">Контакты</div>
                    <div class="side-menu">
                        <a href="#">
                            <circle cx="295.099" cy="327.254" r="110.96" transform="rotate(-45 295.062 327.332)" />
                            <path d="M471.854 338.281V163.146H296.72v41.169a123.1 123.1 0 01121.339 122.939c0 3.717-.176 7.393-.5 11.027zM172.14 327.254a123.16 123.16 0 01100.59-120.915L195.082 73.786 40.146 338.281H172.64c-.325-3.634-.5-7.31-.5-11.027z" />
                            </svg>
                            Учителей
                        </a>
                    </div>
                </div>
                <div class="side-wrapper">
                    <div class="side-title">Дополнительно</div>
                    <div class="side-menu">
                        <a href="posechaemost.php">
                            <path d="M467 0H45C20.186 0 0 20.186 0 45v422c0 24.814 20.186 45 45 45h422c24.814 0 45-20.186 45-45V45c0-24.814-20.186-45-45-45zM181 241c41.353 0 75 33.647 75 75s-33.647 75-75 75-75-33.647-75-75c0-8.291 6.709-15 15-15s15 6.709 15 15c0 24.814 20.186 45 45 45s45-20.186 45-45-20.186-45-45-45c-41.353 0-75-33.647-75-75s33.647-75 75-75 75 33.647 75 75c0 8.291-6.709 15-15 15s-15-6.709-15-15c0-24.814-20.186-45-45-45s-45 20.186-45 45 20.186 45 45 45zm180 120h30c8.291 0 15 6.709 15 15s-6.709 15-15 15h-30c-24.814 0-45-20.186-45-45V211h-15c-8.291 0-15-6.709-15-15s6.709-15 15-15h15v-45c0-8.291 6.709-15 15-15s15 6.709 15 15v45h45c8.291 0 15 6.709 15 15s-6.709 15-15 15h-45v135c0 8.276 6.724 15 15 15z"
                            />
                            </svg>
                            График посещаемости
                        </a>
                        <a href="#">
                            <path d="M255.721 347.484L90.22 266.751v106.57l165.51 73.503 165.509-73.503V266.742z" />
                            <path d="M511.441 189.361L255.721 64.617 0 189.361l255.721 124.744 195.522-95.378v111.032h30V204.092z" />
                            </svg>
                            Заказать справки
                        </a>
                        <a href="MINIGAME/index.php">
                            <path d="M196 151h-75v90h75c24.814 0 45-20.186 45-45s-20.186-45-45-45z" />
                            <path d="M467 0H45C20.186 0 0 20.186 0 45v422c0 24.814 20.186 45 45 45h422c24.814 0 45-20.186 45-45V45c0-24.814-20.186-45-45-45zM196 271h-75v105c0 8.291-6.709 15-15 15s-15-6.709-15-15V136c0-8.291 6.709-15 15-15h90c41.353 0 75 33.647 75 75s-33.647 75-75 75zm210-60c8.291 0 15 6.709 15 15s-6.709 15-15 15h-45v135c0 8.291-6.709 15-15 15s-15-6.709-15-15V241h-15c-8.291 0-15-6.709-15-15s6.709-15 15-15h15v-45c0-24.814 20.186-45 45-45h30c8.291 0 15 6.709 15 15s-6.709 15-15 15h-30c-8.276 0-15 6.724-15 15v45h45z"
                            />
                            </svg>
                            Мини игра
                        </a>
                        <a href="news.php">
                            <path d="M181 181h-60v60h60c16.54 0 30-13.46 30-30s-13.46-30-30-30zm0 0M181 271h-60v60h60c16.54 0 30-13.46 30-30s-13.46-30-30-30zm0 0M346 241c-19.555 0-36.238 12.54-42.438 30h84.875c-6.199-17.46-22.882-30-42.437-30zm0 0" />
                            <path d="M436 0H75C33.648 0 0 33.648 0 75v362c0 41.352 33.648 75 75 75h361c41.352 0 76-33.648 76-75V75c0-41.352-34.648-75-76-75zM286 151h120v30H286zm-45 150c0 33.09-26.91 60-60 60H91V151h90c33.09 0 60 26.91 60 60 0 18.008-8.133 33.996-20.73 45 12.597 11.004 20.73 26.992 20.73 45zm180 0H303.562c6.196 17.46 22.883 30 42.438 30 16.012 0 30.953-8.629 38.992-22.516l25.957 15.032C397.58 346.629 372.687 361 346 361c-41.352 0-75-33.648-75-75s33.648-75 75-75 75 33.648 75 75zm0 0"
                            />
                            </svg>
                            Новости колледжа
                        </a>
                    </div>
                </div>
            </div>
            <div class="main-container">
                <div class="main-header">
                    <a class="menu-link-main" href="index.php">На главную</a>
                    <div class="header-menu">
                        <a class="main-header-link is-active" href="kab.php">Личный кабинет</a>
                        <a class="main-header-link" href="marks.php">Оценки</a>
                        <a class="main-header-link" href="uroki.php">Расписание</a>

                    </div>
                </div>
                <div class="content-wrapper">
                    <div class="content-wrapper-header">
                    <table class="table-fill">
                        
                   <thead>
<tr>
</tr>
</thead>


<tbody class="table-hover">
<?php
    foreach ($array as $arr){
 
  $html .= '<tr>';
  $html .= '<td scope="row">'.$i.'</td>';
  foreach ($arr as $td) {
    $html .= '<td scope="col">'.$td.'</td>';
  }
  $html .= '';
}
echo $html;
    ?> 
</tbody>
</table>
  
                        <div class="content-section">
                        </div>
                    </div>
                    <div class="overlay-app"></div>
                </div>
                <!-- partial -->
                <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
                <script src="./script.js"></script>

</body>

</html>