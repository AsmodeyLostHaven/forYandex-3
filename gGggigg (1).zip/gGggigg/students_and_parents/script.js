$(function () {
    $(".menu-link").click(function () {
     $(".menu-link").removeClass("is-active");
     $(this).addClass("is-active");
    });
   });
   
   $(function () {
    $(".main-header-link").click(function () {
     $(".main-header-link").removeClass("is-active");
     $(this).addClass("is-active");
    });
   });
   
   const dropdowns = document.querySelectorAll(".dropdown");
   dropdowns.forEach((dropdown) => {
    dropdown.addEventListener("click", (e) => {
     e.stopPropagation();
     dropdowns.forEach((c) => c.classList.remove("is-active"));
     dropdown.classList.add("is-active");
    });
   });
   
   $(".search-bar input")
    .focus(function () {
     $(".header").addClass("wide");
    })
    .blur(function () {
     $(".header").removeClass("wide");
    });
   
   $(document).click(function (e) {
    var container = $(".status-button");
    var dd = $(".dropdown");
    if (!container.is(e.target) && container.has(e.target).length === 0) {
     dd.removeClass("is-active");
    }
   });
   
   $(function () {
    $(".dropdown").on("click", function (e) {
     $(".content-wrapper").addClass("overlay");
     e.stopPropagation();
    });
    $(document).on("click", function (e) {
     if ($(e.target).is(".dropdown") === false) {
      $(".content-wrapper").removeClass("overlay");
     }
    });
   });
   
   $(function () {
    $(".status-button:not(.open)").on("click", function (e) {
     $(".overlay-app").addClass("is-active");
    });
    $(".pop-up .close").click(function () {
     $(".overlay-app").removeClass("is-active");
    });
   });
   
   $(".status-button:not(.open)").click(function () {
    $(".pop-up").addClass("visible");
   });
   
   $(".pop-up .close").click(function () {
    $(".pop-up").removeClass("visible");
   });
   
   const toggleButton = document.querySelector('.dark-light');
   
   toggleButton.addEventListener('click', () => {
     document.body.classList.toggle('light-mode');
   });
const start = () => {
    // Initialize the JavaScript client library 
    // https://sheets.googleapis.com/v4/spreadsheets/1wtNdDAXRL0D-7isbVWCgt8oW5wsfmH3B00m620Mg6uY/?key=AIzaSyCrB3NcC8wfeQiLQOq2KvHJ4QIQDuv8E3M&includeGridData=true
    gapi.client.init({
        'apiKey': 'AIzaSyCrB3NcC8wfeQiLQOq2KvHJ4QIQDuv8E3M',
        'discoveryDocs': ["https://sheets.googleapis.com/$discovery/rest?version=v4"],
    }).then(() => {
        return gapi.client.sheets.spreadsheets.values.get({
            spreadsheetId: '1wtNdDAXRL0D-7isbVWCgt8oW5wsfmH3B00m620Mg6uY',
            range: 'food!A1:E4', // for example: List 1!A1:B6
        })
    }).then((response) => {
        // Parse the response data
        const loadedData = response.result.values;

        // populate HTML table with data
        const table = document.getElementsByTagName('table')[0];

        // add column headers
        const columnHeaders = document.createElement('tr');
        columnHeaders.innerHTML = `<th>${loadedData[0][0]}</th>
<th>${loadedData[0][1]}</th>`;
        table.appendChild(columnHeaders);

        // add table data rows
        for (let i = 1; i < loadedData.length; i++) {
            const tableRow = document.createElement('tr');
            tableRow.innerHTML = `<td>${loadedData[i][0]}</td>
<td>${loadedData[i][1]}</td>`;
            table.appendChild(tableRow);
        }
    }).catch((err) => {
        console.log(err.error.message);
    });
};

// Load the JavaScript client library
gapi.load('client', start);